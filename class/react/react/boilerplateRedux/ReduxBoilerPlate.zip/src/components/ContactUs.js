import React, { Component } from 'react';

class ContactUs extends Component {
  render() {
    return (
      <div >
        ContactUs
      </div>
    );
  }
}

export default ContactUs;
