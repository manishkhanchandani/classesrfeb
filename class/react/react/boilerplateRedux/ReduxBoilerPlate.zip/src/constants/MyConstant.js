const MyConstant = {
  SAMPLE: 'SAMPLE'
};

export default MyConstant;
