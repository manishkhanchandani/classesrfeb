
angular.module('myApp').component('counterRows', {
  template: '<div class="notifyRows row"><div class="col-sm-6 col-xs-6 col-lg-6 col-md-6 counter">{{$ctrl.number}}</div><div class="col-sm-6 col-xs-6 col-lg-6 col-md-6 counterText">{{$ctrl.name}}</div></div>',
  bindings: {
    'number': '@',
    'name': '@'
  }
});