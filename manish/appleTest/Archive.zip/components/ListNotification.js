
angular.module('myApp').component('listNotification', {
  templateUrl: 'components/ListNotification.html',
  bindings: {
    'collection': '='
  }
});