// http://www.hiredintech.com/system-design/the-system-design-process/





Use Cases:

1. shortening: take url => return a shorter url
2. redirection: take a short url => redirect to the original url

high availability of the system

traffic?

how many request per sec?
how many new url per sec?

10% shortening 90% from redirection

data?



out of scope
3. custom url
4. analytics
5. automatic link expriation
6. manual link removal
7. UI vs API